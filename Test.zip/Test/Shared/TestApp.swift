//
//  TestApp.swift
//  Shared
//
//  Created by user on 15.10.2022.
//

import SwiftUI

@main
struct TestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
